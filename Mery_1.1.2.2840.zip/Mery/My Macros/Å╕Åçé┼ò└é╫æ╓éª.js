// -----------------------------------------------------------------------------
// �����ŕ��בւ�
//
// Copyright (c) Kuro. All Rights Reserved.
// e-mail: kuro@haijin-boys.com
// www:    http://www.haijin-boys.com/
// -----------------------------------------------------------------------------

if (document.selection.Text == "")
	document.selection.SelectAll();
document.selection.Text = document.selection.Text.split("\n").sort().join("\n");
document.selection.StartOfDocument();
