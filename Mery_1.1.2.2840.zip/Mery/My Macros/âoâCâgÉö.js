// -----------------------------------------------------------------------------
// �o�C�g��
//
// Copyright (c) Kuro. All Rights Reserved.
// e-mail: kuro@haijin-boys.com
// www:    http://www.haijin-boys.com/
// -----------------------------------------------------------------------------

with (document) {
	var s = document.selection.Text;
	if (s == "")
		s = Text;
	var j = 0;
	var l = s.length;
	for (var i = 0; i < l; i++) {
		var c = s.charCodeAt(i);
		if ((c >= 0x0 && c < 0x81) || (c == 0xf8f0) || (c >= 0xff61 && c < 0xffa0) || (c >= 0xf8f1 && c < 0xf8f4))
			j += 1;
		else
			j += 2;
	}
	window.status = ("" + j).match(/./g).reverse().join("").replace(/(\d{3})/g, "$1,").match(/./g).reverse().join("").replace(/^,/, "") + " �o�C�g";
}
